import os
import sys

if os.path.abspath("..") not in sys.path:
    sys.path.append(os.path.abspath(".."))

from graphslim.config import get_args
from graphslim.dataset.loader import get_dataset, TransAndInd
from graphslim.dataset.split_tool import split_dataset 
from graphslim.utils import to_camel_case, seed_everything

if __name__ == "__main__":
    args = get_args()
    seed_everything(args.seed)
    # graph = get_dataset(args.dataset, args, args.load_path)

    data = get_dataset(args.dataset, args=args, load_path="../../data")
    data = TransAndInd(data, dataset=args.dataset, norm=True)
    split_dataset(data, args, n_splits=5, out_dir="../checkpoints/evolve_dataset")
