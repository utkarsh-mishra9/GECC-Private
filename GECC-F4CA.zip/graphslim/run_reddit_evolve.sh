#!/bin/bash

# -----------------------------------------------------------------------------
# 1) ACTIVATE YOUR CONDA ENV
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
# 2) DEFINE HYPERPARAMETERS
# -----------------------------------------------------------------------------
DATASET="ogbn-products"        # Dataset name
METHOD="gecc"         # Method name
FUZZINESS=1        # Fuzziness hyperparameter
REP=1               # Replication count

# -----------------------------------------------------------------------------
# 3) DETERMINE WHETHER TO RUN EVOLVING OR NON-EVOLVING SETTING
# -----------------------------------------------------------------------------
if [ -n "$1" ]; then
    # If $1 is provided, run evolving setting with multiple splits
    sis=("1" "1+2" "1+2+3" "1+2+3+4" "1+2+3+4+5")
    EVOLVE_FLAG="--evolve"
    AGG_ALPHA=0.1        # Alpha hyperparameter
    AGG_BETA=0.9         # Beta hyperparameter
    AGG_GAMMA=0.5       # Gamma hyperparameter
    EWD=0.0005           # EWD hyperparameter
else
    # Otherwise, run non-evolving setting for only "1+2+3+4+5"
    sis=("1+2+3+4+5")
    EVOLVE_FLAG=""
    AGG_ALPHA=0.2        # Alpha hyperparameter
    AGG_BETA=0.9         # Beta hyperparameter
    AGG_GAMMA=0.7       # Gamma hyperparameter
    EWD=0.0005           # EWD hyperparameter
fi

# -----------------------------------------------------------------------------
# 4) RUN TRAINING LOCALLY FOR EACH SPLIT
# -----------------------------------------------------------------------------
for si in "${sis[@]}"; do

  echo "==== Starting job with dataset=${DATASET}, method=${METHOD}, si=${si} ===="
  echo "alpha=${AGG_ALPHA}, beta=${AGG_BETA}, gamma=${AGG_GAMMA}, ewd=${EWD}, fuzziness=${FUZZINESS}, rep=${REP}"

  python train_split.py \
    --dataset   "${DATASET}" \
    --method    "${METHOD}"  \
    --si        "${si}"      \
    --agg_alpha "${AGG_ALPHA}" \
    --agg_beta  "${AGG_BETA}"  \
    --agg_gamma "${AGG_GAMMA}" \
    --ewd       "${EWD}" \
    --fuzziness "${FUZZINESS}" \
    --rep_fuzz  "${REP}" \
    $EVOLVE_FLAG  # Conditionally add --evolve only if evolving mode is enabled

  echo "==== Finished SI=${si} ===="

done

echo "All runs finished."

