import json
import os.path as osp
import os
import pickle
from collections import defaultdict
import numpy as np
import scipy.sparse as sp
import torch
import torch.nn as nn
from tqdm import tqdm
from typing import Union, List
from functools import reduce
import operator
import torch.nn.functional as F
from ogb.nodeproppred import PygNodePropPredDataset
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from torch_geometric.datasets import Planetoid, Coauthor, CitationFull, Amazon, Flickr, Reddit2
from torch_geometric.loader import NeighborSampler
from torch_geometric.utils import to_undirected, add_self_loops
from torch_sparse import SparseTensor
from dgl.data import FraudDataset
import shutil

from graphslim.dataset.convertor import ei2csr, csr2ei, from_dgl
from graphslim.dataset.loader import get_dataset
from graphslim.dataset.utils import splits
from graphslim.utils import index_to_mask, to_tensor,  mask_to_index, normalize_adj_tensor


def split_dataset(
    data, args, n_splits=5, out_dir="../checkpoints/evolve_dataset", verbose=True
):
    """
    Splits the dataset into multiple class-balanced splits based on the training mask.

    Each split will contain approximately `train_mask.sum() // n_splits` nodes,
    distributed evenly across classes with at least one node per class.

    Parameters
    ----------
    data : TransAndInd
        The data object containing graph information.
    args : object
        Configuration and arguments. Should have at least:
            - args.dataset (str)
            - args.seed (int)
            - args.setting ('trans' or 'ind')
    n_splits : int
        Number of splits to create. Default is 5.
    out_dir : str
        Directory to save the splits. Default is '../checkpoints/evolve_dataset'.
    verbose : bool
        If True, prints verbose output. Default is True.
    """
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)

    dataset_name = args.dataset
    split_base_dir = os.path.join(out_dir, dataset_name)
    if not os.path.exists(split_base_dir):
        os.makedirs(split_base_dir)

    # Ensure data.labels_full is set
    if not hasattr(data, "labels_full") or data.labels_full is None:
        if hasattr(data, "y") and data.y is not None:
            data.labels_full = data.y
        elif hasattr(data, "labels") and data.labels is not None:
            data.labels_full = data.labels
        else:
            raise AttributeError(
                "data.labels_full is not set and cannot be inferred from data."
            )

    y_train = data.labels_train.cpu().numpy()
    train_indices = data.idx_train.cpu().numpy()
    nclass = y_train.max() + 1

    total_train_nodes = train_indices.size
    desired_per_split = total_train_nodes // n_splits

    if desired_per_split < nclass:
        raise ValueError(
            f"Desired per split ({desired_per_split}) is less than number of classes ({nclass}). "
            "Increase train nodes or decrease number of splits."
        )

    # Initialize list of splits
    splits = [[] for _ in range(n_splits)]

    # For reproducibility
    np.random.seed(args.seed)

    # Organize train indices per class
    class_to_indices = defaultdict(list)
    for idx in train_indices:
        class_label = data.labels_full[idx].item()
        class_to_indices[class_label].append(idx)

    # Determine desired number per class per split
    desired_per_class_per_split = {}
    for c in range(nclass):
        total_class_nodes = len(class_to_indices[c])
        per_split = total_class_nodes // n_splits
        remainder = total_class_nodes % n_splits
        # Distribute the remainder one by one to the first 'remainder' splits
        counts = [
            per_split + 1 if i < remainder else per_split for i in range(n_splits)
        ]
        desired_per_class_per_split[c] = counts

    # Assign nodes to splits
    for c in range(nclass):
        indices = class_to_indices[c]
        np.random.shuffle(indices)
        split_counts = desired_per_class_per_split[c]
        start = 0
        for s in range(n_splits):
            count = split_counts[s]
            if count > 0:
                splits[s].extend(indices[start : start + count])
                start += count

    # Verify that total nodes per split are approximately desired_per_split
    for s in range(n_splits):
        if len(splits[s]) != desired_per_split and s < n_splits - 1:
            print(
                f"Warning: Split {s + 1} has {len(splits[s])} nodes, expected {desired_per_split}."
            )
        # The last split may have more if total_train_nodes is not divisible by n_splits
        elif s == n_splits - 1 and len(splits[s]) < desired_per_split:
            remaining = desired_per_split - len(splits[s])
            # Assign remaining nodes from other splits
            for other_s in range(n_splits):
                if len(splits[other_s]) > desired_per_split:
                    move_nodes = splits[other_s][-remaining:]
                    splits[s].extend(move_nodes)
                    splits[other_s] = splits[other_s][:-remaining]
                    break

    # Save each split
    for split_idx, split_nodes in enumerate(tqdm(splits, desc="Saving Splits"), 1):
        split_dir = os.path.join(split_base_dir, f"split_{split_idx}")
        os.makedirs(split_dir, exist_ok=True)

        if args.setting == "trans":
            # Create a new train_mask for this split
            train_mask = torch.zeros(data.num_nodes, dtype=torch.bool)
            train_mask[split_nodes] = True

            # Assign labels_train, labels_val, labels_test
            # data.labels_train = data.labels_full[train_mask]
            # data.labels_val = data.labels_full[data.val_mask]
            # data.labels_test = data.labels_full[data.test_mask]

            # Save the masks
            torch.save(train_mask, os.path.join(split_dir, "train_mask.pt"))
            torch.save(data.val_mask, os.path.join(split_dir, "val_mask.pt"))
            torch.save(data.test_mask, os.path.join(split_dir, "test_mask.pt"))

            if verbose:
                print(
                    f"[Split {split_idx}] Saved {len(split_nodes)} nodes to {split_dir}."
                )

            print(f"train_nodes num in split: {train_mask.sum()}")

        elif args.setting == "ind":
            # Save the subgraph
            torch.save(split_nodes, os.path.join(split_dir, "subgraph.pt"))

            if verbose:
                print(
                    f"[Split {split_idx}] Saved subgraph with {len(split_nodes)} nodes to {split_dir}."
                )

            print(f"train_nodes num in split: {len(split_nodes)}")

        else:
            raise ValueError("Invalid setting. Choose 'trans' or 'ind'.")

    if verbose:
        print("All splits saved successfully.")

def get_split(args, split_idx: Union[int, str], out_dir="../checkpoints/evolve_dataset"):
    """
    Loads a specific split or accumulated splits of the dataset.

    Parameters
    ----------
    args : object
        Configuration and arguments. Should have at least:
            - args.dataset (str)
            - args.setting ('trans' or 'ind')
    split_idx : int or str
        Index of the split to load (1-based indexing) or a string representing multiple splits (e.g., "1+2").
    out_dir : str, optional
        Directory where splits are saved. Default is '../checkpoints/evolve'.

    Returns
    -------
    data : object
        The loaded and combined data object for the specified split(s).
    """
    dataset_name = args.dataset
    data = None  # Initialize data

    # Handle single or multiple splits
    if isinstance(split_idx, str) and "+" in split_idx:
        split_indices = [int(idx.strip()) for idx in split_idx.split("+")]
    else:
        split_indices = [int(split_idx)]

    split_dirs = [
        os.path.join(out_dir, dataset_name, f"split_{idx}") for idx in split_indices
    ]

    # Verify all split directories exist
    for sd in split_dirs:
        if not os.path.exists(sd):
            raise FileNotFoundError(f"Split directory {sd} does not exist.")

    print(f"Loading data from splits: {', '.join(split_dirs)}")
    data = copy_data_structure(args)

    if args.setting == "trans":
        # Initialize masks
        combined_train_mask = None
        combined_val_mask = None
        combined_test_mask = None

        for sd in split_dirs:
            # Load masks
            train_mask = torch.load(os.path.join(sd, "train_mask.pt"), weights_only=True)
            val_mask = torch.load(os.path.join(sd, "val_mask.pt"), weights_only=True)
            test_mask = torch.load(os.path.join(sd, "test_mask.pt"), weights_only=True)

            # Combine masks using logical OR
            combined_train_mask = (
                train_mask
                if combined_train_mask is None
                else (combined_train_mask | train_mask)
            )
            combined_val_mask = (
                val_mask
                if combined_val_mask is None
                else (combined_val_mask | val_mask)
            )
            combined_test_mask = (
                test_mask
                if combined_test_mask is None
                else (combined_test_mask | test_mask)
            )

        # Create a copy of the original data structure from the first split

        # Apply combined masks
        data.train_mask = combined_train_mask
        data.val_mask = combined_val_mask
        data.test_mask = combined_test_mask
        data.idx_train = mask_to_index(combined_train_mask, data.num_nodes)
        data.feat_train = data.feat_full[combined_train_mask]

        # Ensure labels_full is not None
        if hasattr(data, "labels_full") and data.labels_full is not None:
            data.labels_train = data.labels_full[combined_train_mask]
            data.labels_val = data.labels_full[combined_val_mask]
            data.labels_test = data.labels_full[combined_test_mask]
        else:
            raise AttributeError(
                "data.labels_full is None. Ensure it is properly initialized."
            )

        print(f"train_nodes num in split: {combined_train_mask.sum()}")
        print(f"val_nodes num in split: {combined_val_mask.sum()}")
        print(f"test_nodes num in split: {combined_test_mask.sum()}")

    elif args.setting == "ind":
        # Load all subgraphs
        split_nodes = []
        for sd in split_dirs:
            subgraph_path = os.path.join(sd, "subgraph.pt")
            if not os.path.exists(subgraph_path):
                raise FileNotFoundError(
                    f"Subgraph file {subgraph_path} does not exist."
                )
            idx_train = np.array(torch.load(subgraph_path))
            split_nodes.append(idx_train)
        # Extract subgraph for this split
        split_nodes = np.concatenate(split_nodes, axis=0)
        data.adj_train = data.adj_full[np.ix_(split_nodes, split_nodes)]
        data.labels_train = data.labels_full[split_nodes].view(-1)
        data.feat_train = data.feat_full[split_nodes]
        data.idx_train = split_nodes
        data.num_nodes = (
            data.labels_train.shape[0]
            + data.labels_val.shape[0]
            + data.labels_test.shape[0]
        )

        # Create a data object similar to the transductive setting

        print(
            f"Merged inductive subgraphs into a single graph with {data.num_nodes} nodes."
        )

    else:
        raise ValueError("Invalid setting. Choose 'trans' or 'ind'.")

    return data


def copy_data_structure(args):
    """
    Copies the structure of the original data object.

    Parameters
    ----------
    args : object
        Configuration and arguments.
    split_dir : str
        Directory where the split is saved.

    Returns
    -------
    data : object
        A new data object with updated masks.
    """
    # This function needs to be implemented based on your data structure.
    # Here's a placeholder example assuming you're using PyG Data.

    # Load the original dataset
    original_data = get_dataset(name=args.dataset, args=args)

    # Create a deep copy
    import copy

    data = copy.deepcopy(original_data)

    return data
